import axios from 'axios';
import { ApiUrls } from "../ApiUrls/apiUrls";

/**
 * 
 * @method POST
 * @param {Object} data 
 * @returns {Promise<{status: boolean, error: *}|{status: boolean, body: *}>}
 * @comment Create the user.
 */
export const registerUser = async (data) => {
    try {
        console.log(data, "data", ApiUrls.REGISTER)
        const result = await axios.post(ApiUrls.REGISTER, data);
        console.log(result, "12")
        return {
            status: true,
            data: result?.data?.data
        }
    } catch (error) {
        return {
            status: false,
            error: error?.response?.data?.message

        }
    }
}